# Datheon — Machine Learning & Data Science Internship

This repository contains two completed machine-learning projects prepared for the Datheon internship submission.

## Projects

### Task 1 — Multi-Class Iris Classification
**Folder:** `Task_1_Iris_Classification/`

- Dataset: 150 records and 5 columns.
- Target: `species` (three Iris species).
- Models: Logistic Regression and Decision Tree.
- Workflow: data inspection, exploratory analysis, stratified train/test split, feature scaling, model evaluation, confusion matrices, model comparison, and PCA decision-boundary visualisation.

### Task 2 — Predictive Customer Churn Classification
**Folder:** `Task_2_Customer_Churn/`

- Dataset: 7,043 records and 21 columns.
- Target: `Churn` (`Yes` / `No`).
- Models: Random Forest and XGBoost (with a HistGradientBoosting fallback if XGBoost is not installed).
- Workflow: data cleaning, missing-value handling, categorical encoding, stratified train/test split, class-imbalance handling, evaluation metrics, ROC curves, confusion matrices, and feature importance.

## Repository structure

```text
Datheon_Machine_Learning_&_Data_Science_Internship/
├── Task_1_Iris_Classification/
│   ├── Iris_Classification.ipynb
│   └── iris_dataset.csv
├── Task_2_Customer_Churn/
│   ├── Customer_Churn_Prediction.ipynb
│   └── Telco_Customer_Churn_User_Dataset.csv
├── README.md
└── requirements.txt
```

## How to run

1. Download or clone this repository.
2. Open either `.ipynb` notebook in Jupyter Notebook, JupyterLab, Google Colab, or Kaggle.
3. Keep the corresponding CSV beside the notebook. In Kaggle, alternatively attach the CSV as an input dataset.
4. Run all cells from top to bottom.

## Install dependencies

```bash
pip install -r requirements.txt
```

## Notes

- The notebooks use a fixed random seed (`42`) so the train/test split is reproducible.
- Report the actual evaluation scores generated when you run the notebooks; do not assume a target score in advance.
- The CSV files are included here to make the projects reproducible. Check the original Kaggle dataset page for its licence and attribution requirements before redistributing the data publicly.
